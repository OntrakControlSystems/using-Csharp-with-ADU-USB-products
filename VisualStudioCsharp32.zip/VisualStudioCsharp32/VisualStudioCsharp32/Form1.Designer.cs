﻿namespace Project1
{

    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.TextBox1 = new System.Windows.Forms.TextBox();
            this.StandardControls = new System.Windows.Forms.GroupBox();
            this.TextBox2 = new System.Windows.Forms.TextBox();
            this.CloseButton = new System.Windows.Forms.Button();
            this.ReadButton = new System.Windows.Forms.Button();
            this.WriteButton = new System.Windows.Forms.Button();
            this.OpenButton = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.DiscoveryControls = new System.Windows.Forms.GroupBox();
            this.GetADUButton = new System.Windows.Forms.Button();
            this.ADUCountButton = new System.Windows.Forms.Button();
            this.ShowListButton = new System.Windows.Forms.Button();
            this.SelectiveOC = new System.Windows.Forms.GroupBox();
            this.OpenSNOButton = new System.Windows.Forms.Button();
            this.TextBox3 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.StandardControls.SuspendLayout();
            this.DiscoveryControls.SuspendLayout();
            this.SelectiveOC.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 75);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Data to send";
            this.label1.Click += new System.EventHandler(this.Label1_Click);
            // 
            // TextBox1
            // 
            this.TextBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TextBox1.Location = new System.Drawing.Point(15, 106);
            this.TextBox1.Name = "TextBox1";
            this.TextBox1.Size = new System.Drawing.Size(220, 20);
            this.TextBox1.TabIndex = 0;
            // 
            // StandardControls
            // 
            this.StandardControls.Controls.Add(this.TextBox2);
            this.StandardControls.Controls.Add(this.CloseButton);
            this.StandardControls.Controls.Add(this.ReadButton);
            this.StandardControls.Controls.Add(this.WriteButton);
            this.StandardControls.Controls.Add(this.OpenButton);
            this.StandardControls.Controls.Add(this.label2);
            this.StandardControls.Controls.Add(this.label1);
            this.StandardControls.Controls.Add(this.TextBox1);
            this.StandardControls.Location = new System.Drawing.Point(12, 12);
            this.StandardControls.Name = "StandardControls";
            this.StandardControls.Size = new System.Drawing.Size(418, 261);
            this.StandardControls.TabIndex = 2;
            this.StandardControls.TabStop = false;
            this.StandardControls.Text = "Standard Controls";
            // 
            // TextBox2
            // 
            this.TextBox2.AcceptsReturn = true;
            this.TextBox2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TextBox2.Enabled = false;
            this.TextBox2.Location = new System.Drawing.Point(15, 148);
            this.TextBox2.Name = "TextBox2";
            this.TextBox2.Size = new System.Drawing.Size(220, 20);
            this.TextBox2.TabIndex = 6;
            // 
            // CloseButton
            // 
            this.CloseButton.Location = new System.Drawing.Point(280, 190);
            this.CloseButton.Name = "CloseButton";
            this.CloseButton.Size = new System.Drawing.Size(120, 50);
            this.CloseButton.TabIndex = 5;
            this.CloseButton.Text = "Close ";
            this.CloseButton.UseVisualStyleBackColor = true;
            this.CloseButton.Click += new System.EventHandler(this.CloseButton_Click);
            // 
            // ReadButton
            // 
            this.ReadButton.Location = new System.Drawing.Point(280, 132);
            this.ReadButton.Name = "ReadButton";
            this.ReadButton.Size = new System.Drawing.Size(120, 50);
            this.ReadButton.TabIndex = 4;
            this.ReadButton.Text = "Read";
            this.ReadButton.UseVisualStyleBackColor = true;
            this.ReadButton.Click += new System.EventHandler(this.ReadButton_Click);
            // 
            // WriteButton
            // 
            this.WriteButton.Location = new System.Drawing.Point(280, 76);
            this.WriteButton.Name = "WriteButton";
            this.WriteButton.Size = new System.Drawing.Size(120, 50);
            this.WriteButton.TabIndex = 3;
            this.WriteButton.Text = "Write";
            this.WriteButton.UseVisualStyleBackColor = true;
            this.WriteButton.Click += new System.EventHandler(this.WriteButton_Click);
            // 
            // OpenBotton
            // 
            this.OpenButton.Location = new System.Drawing.Point(280, 19);
            this.OpenButton.Name = "OpenBotton";
            this.OpenButton.Size = new System.Drawing.Size(120, 50);
            this.OpenButton.TabIndex = 2;
            this.OpenButton.Text = "Open";
            this.OpenButton.UseVisualStyleBackColor = true;
            this.OpenButton.Click += new System.EventHandler(this.OpenButton_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 181);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Received Data";
            this.label2.Click += new System.EventHandler(this.Label2_Click);
            // 
            // DiscoveryControls
            // 
            this.DiscoveryControls.Controls.Add(this.GetADUButton);
            this.DiscoveryControls.Controls.Add(this.ADUCountButton);
            this.DiscoveryControls.Controls.Add(this.ShowListButton);
            this.DiscoveryControls.Location = new System.Drawing.Point(12, 291);
            this.DiscoveryControls.Name = "DiscoveryControls";
            this.DiscoveryControls.Size = new System.Drawing.Size(418, 107);
            this.DiscoveryControls.TabIndex = 3;
            this.DiscoveryControls.TabStop = false;
            this.DiscoveryControls.Text = "Discovery Controls";
            // 
            // GetADUButton
            // 
            this.GetADUButton.Location = new System.Drawing.Point(280, 35);
            this.GetADUButton.Name = "GetADUButton";
            this.GetADUButton.Size = new System.Drawing.Size(120, 50);
            this.GetADUButton.TabIndex = 8;
            this.GetADUButton.Text = "Get ADU";
            this.GetADUButton.UseVisualStyleBackColor = true;
            this.GetADUButton.Click += new System.EventHandler(this.GetADUButton_Click);
            // 
            // ADUCountButton
            // 
            this.ADUCountButton.Location = new System.Drawing.Point(145, 35);
            this.ADUCountButton.Name = "ADUCountButton";
            this.ADUCountButton.Size = new System.Drawing.Size(120, 50);
            this.ADUCountButton.TabIndex = 7;
            this.ADUCountButton.Text = "ADU Count";
            this.ADUCountButton.UseVisualStyleBackColor = true;
            this.ADUCountButton.Click += new System.EventHandler(this.ADUCountButton_Click);
            // 
            // ShowListButton
            // 
            this.ShowListButton.Location = new System.Drawing.Point(6, 35);
            this.ShowListButton.Name = "ShowListButton";
            this.ShowListButton.Size = new System.Drawing.Size(120, 50);
            this.ShowListButton.TabIndex = 6;
            this.ShowListButton.Text = "Show List";
            this.ShowListButton.UseVisualStyleBackColor = true;
            this.ShowListButton.Click += new System.EventHandler(this.ShowListButton_Click);
            // 
            // SelectiveOC
            // 
            this.SelectiveOC.Controls.Add(this.OpenSNOButton);
            this.SelectiveOC.Controls.Add(this.TextBox3);
            this.SelectiveOC.Controls.Add(this.label3);
            this.SelectiveOC.Location = new System.Drawing.Point(12, 415);
            this.SelectiveOC.Name = "SelectiveOC";
            this.SelectiveOC.Size = new System.Drawing.Size(418, 115);
            this.SelectiveOC.TabIndex = 4;
            this.SelectiveOC.TabStop = false;
            this.SelectiveOC.Text = "Selective Open Controls";
            // 
            // OpenSNOBotton
            // 
            this.OpenSNOButton.Location = new System.Drawing.Point(280, 43);
            this.OpenSNOButton.Name = "OpenSNOBotton";
            this.OpenSNOButton.Size = new System.Drawing.Size(120, 50);
            this.OpenSNOButton.TabIndex = 2;
            this.OpenSNOButton.Text = "Open by s/no";
            this.OpenSNOButton.UseVisualStyleBackColor = true;
            this.OpenSNOButton.Click += new System.EventHandler(this.OpenSNOButton_Click);
            // 
            // TextBox3
            // 
            this.TextBox3.Location = new System.Drawing.Point(15, 55);
            this.TextBox3.Name = "TextBox3";
            this.TextBox3.Size = new System.Drawing.Size(220, 20);
            this.TextBox3.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 30);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(143, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Serial Number (s/no) to open";
            this.label3.Click += new System.EventHandler(this.Label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(24, 544);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(389, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Copright 2019 - Ontrak Control Systems Inc.           www.ontrak.net";
            this.label4.UseWaitCursor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(462, 577);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.SelectiveOC);
            this.Controls.Add(this.DiscoveryControls);
            this.Controls.Add(this.StandardControls);
            this.Name = "Form1";
            this.Text = "Visual Studio 2019 C# Example (64-bit)";
            this.StandardControls.ResumeLayout(false);
            this.StandardControls.PerformLayout();
            this.DiscoveryControls.ResumeLayout(false);
            this.SelectiveOC.ResumeLayout(false);
            this.SelectiveOC.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TextBox1;
        private System.Windows.Forms.GroupBox StandardControls;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox DiscoveryControls;
        private System.Windows.Forms.GroupBox SelectiveOC;
        private System.Windows.Forms.TextBox TextBox3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button CloseButton;
        private System.Windows.Forms.Button ReadButton;
        private System.Windows.Forms.Button WriteButton;
        private System.Windows.Forms.Button OpenButton;
        private System.Windows.Forms.Button GetADUButton;
        private System.Windows.Forms.Button ADUCountButton;
        private System.Windows.Forms.Button ShowListButton;
        private System.Windows.Forms.Button OpenSNOButton;
        private System.Windows.Forms.TextBox TextBox2;
        private System.Windows.Forms.Label label4;

    }
}

