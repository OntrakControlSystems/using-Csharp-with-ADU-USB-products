﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Required by the Windows Form Designer 
        //Private System.ComponentModel.IContainer components;
        public System.Windows.Forms.ToolTip ToolTip1;
        private int aduHandle;

        #region Open Button
        private void OpenButton_Click(System.Object eventSender, System.EventArgs eventArgs)
        {
            aduHandle = Module.OpenAduDevice(1);
            //Opens the handle to the ADU device connect to the USB port
        }
        #endregion

        #region Write Button
        private void WriteButton_Click(System.Object eventSender, System.EventArgs eventArgs)
        {
            int iRC;
            int iBytesWritten = default(int);
            var arglepBuffer = TextBox1.Text;
            iRC = Module.WriteAduDevice(aduHandle, arglepBuffer, TextBox1.Text.Length, ref iBytesWritten, 500);
            //Sends the ASCII command to the ADU device
        }
        #endregion

        #region Read Button
        private void ReadButton_Click(System.Object eventSender, System.EventArgs eventArgs)
        {
            int iRC;
            int iBytesRead = 0;
            StringBuilder sResponse = new StringBuilder(32);
            sResponse.Append("No Data");
            // The preloaded string is "+++No Data+++" which will be displayed if there is no returned data.

            iRC = Module.ReadAduDevice(aduHandle, sResponse, 7, iBytesRead, 500);
            TextBox2.Text = sResponse.ToString();
            //Displays the received ASCII string in the Textbox
        }
        #endregion

        #region Close Button

        private void CloseButton_Click(System.Object eventSender, System.EventArgs eventArgs)
        {
            Module.CloseAduDevice(aduHandle);
            aduHandle = 0;
            //Closes the handle to the ADU device connected to the USB port
        }

        #endregion

        #region Show List Button
        private void ShowListButton_Click(System.Object eventSender, System.EventArgs eventArgs)
        {
            Module.ADU_DEVICE_ID myAduDeviceId = default(Module.ADU_DEVICE_ID);
            int iRC;
            var argsPrompt = "Connect ADU Devices";
            iRC = Module.ShowAduDeviceList(ref myAduDeviceId, argsPrompt);
            //Displays the available ADU Device(s)
        }
        #endregion

        #region ADU Count Button
        private void ADUCountButton_Click(System.Object eventSender, System.EventArgs eventArgs)
        {
            MessageBox.Show("ADU Count: " + Module.ADUCount(100));
            //Max 100 ADU device
            //Counts the number of ADU device(s) plugged in
        }

        #endregion

        #region Get ADU Button
        private void GetADUButton_Click(System.Object sender, System.EventArgs e)
        {
            Module.ADU_DEVICE_ID pADU = default(Module.ADU_DEVICE_ID);

            for (int iAduIndex = 0; iAduIndex <= Module.ADUCount(100) - 1; iAduIndex++)
            {
                Module.GetADU(ref pADU, iAduIndex, 100);
                MessageBox.Show("Index: " + iAduIndex + "   Model: " + pADU.iProductId + "   Serial Number: " + pADU.sSerialNumber);
            }
            //Displays the ADU device(s) information 
        }
        #endregion

        #region Open s/no Button

        private void OpenSNOButton_Click(object sender, EventArgs e)
        {
            var argpSerialNumber = TextBox3.Text;
            aduHandle = Module.OpenAduDeviceBySerialNumber(argpSerialNumber, 1);
            //Opens the ADU device by its serial number 
        }
        #endregion

        #region Labels

        private void Label1_Click(object sender, EventArgs e)
        {
        }

        private void Label2_Click(object sender, EventArgs e)
        {
        }

        private void Label3_Click(object sender, EventArgs e)
        {
        }
        #endregion

    }
}

